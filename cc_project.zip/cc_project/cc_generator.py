import random
import datetime
from os import system

def gen_card(bin, exp_m, exp_y, cvv):
    # Generate card number
    card_number = bin
    for _ in range(15 - len(bin)):
        digit = random.randint(0, 9)
        card_number += str(digit)
    digits = [int(x) for x in card_number]
    for i in range(0, 16, 2):
        digits[i] *= 2
        if digits[i] > 9:
            digits[i] -= 9
    total = sum(digits)
    check_digit = (10 - (total % 10)) % 10
    card_number += str(check_digit)

    # Generate expiration month
    if exp_m == "":
        exp_m = str(random.randint(1, 12)).zfill(2)
    else:
        exp_m = exp_m.zfill(2)

    # Generate expiration year
    if exp_y == "":
        current_year = datetime.datetime.now().year
        random_offset = random.randint(1, 5)
        exp_y = str(current_year + random_offset)
    elif int(exp_y) >= 10 and int(exp_y) <= 99:
        exp_y = "20" + exp_y

    # Generate CVV
    if cvv == "":
        cvv = str(random.randint(0, 999)).zfill(3)
    else:
        cvv = cvv.zfill(3)

    # Format hasil
    return f"{card_number}|{exp_m}|{exp_y}|{cvv}"

# Main program
try:
    system("cls")
except:
    system("clear")

a = input("Bin: ")
b = input("Month(Empty for random): ")
c = input("Year(Empty for random): ")
d = input("CVV(Empty for random): ")
e = int(input("Quantity: "))

# Generate semua kartu dan simpan dalam list
generated_cards = [gen_card(a, b, c, d) for _ in range(e)]

# Simpan ke file dengan mode "w" agar file ditimpa dengan yang baru
with open("cc_list.txt", "w") as file:
    file.write("\n".join(generated_cards) + "\n")

# Tampilkan hasil di terminal
print("\n".join(generated_cards))
print("\nHasil baru telah disimpan di cc_list.txt (mengganti yang lama).")
